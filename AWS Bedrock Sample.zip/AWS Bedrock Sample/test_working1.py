import boto3
import json

prompt_data = "You are travel agent. Give me a planning for the trip to Goa from Mumbai, for 10 days."

bedrock = boto3.client(service_name="bedrock-runtime")
# payload={
#     "prompt":"[INST]" + prompt_data + "[/INST]",
#     "max_gen_len" : 512,
#     "temperature":0.5,
#     "top_p":0.9
# }

payload = {
    "inputText": prompt_data,
    "textGenerationConfig": {
        "maxTokenCount": 512,
        "stopSequences": [],
        "temperature": 0,
        "topP": 1
    }
}

body = json.dumps(payload)
model_id = "amazon.nova-lite-v1:0"
response = bedrock.invoke_model(
    modelId=model_id,
    body=body,
    accept="application/json",
    contentType = "application/json",
)

response_body = json.loads(response.get("body").read())
print(response_body)

response_text = (response_body.get("results")[0]).get('outputText')

print(response_text)